

interface AssocStringString {
    [key: string]: string;
}

interface StudentData {
    name: string;
   score: number;
}
